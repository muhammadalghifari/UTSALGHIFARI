package com.example.uts_alghifari

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val animeList = listOf<Anime>(
            Anime(
                R.drawable.film1,
                nameanime =  "Death Note",
                descanime = "Seperti namanya, Death Note merupakan sebuah buku catatan kematian yang saat seseorang menuliskan nama seseorang di dalamnya akan mengalami kematian sesuai yang tertulis di dalam buku."
            ),
            Anime(
                R.drawable.film2,
                nameanime =  "Fullmetal Alchemist : Brotherhood",
                descanime = "MA Brotherhood ini menceritakan kisah Edward Elric, seorang ahli alkimia alias alchemist bersama dengan Alphonse yang jiwanya terjebak ke dalam baju zirah akibat peristiwa tragis di masa lalu untuk menjadi alkimia terbaik."
            ),
            Anime(
                R.drawable.film3,
                nameanime =  "Attack on Titan",
                descanime = "Di final season-nya, kisah hidup Eren Yeager, Mikasa Ackerman, dan Armin Arlert yang jadi harapan terakhir manusia semakin kompleks saja. Mereka bertemu dengan beberapa karakter baru dan harus berusaha mengalahkan para Titan sebelum semua manusia habis."
            ),
            Anime(
                R.drawable.film4,
                nameanime =  "Naruto Shippuden",
                descanime = "Mengisahkan petualangan tokoh utama Naruto yang bercita-cita menjadi Hokage bersama dengan teman-temannya Sakura, Sasuke dan Kakashi yang menjadi gurunya."
            ),
            Anime(
                R.drawable.film5,
                nameanime =  "Dragon Ball Z",
                descanime = "Dragon Ball yang berkisah mengenai Son Goku ini memiliki berbagai versi seperti Dragon Ball Z, Dragon Ball GT, Dragon Ball Kai, Dragon Ball Super dan masih banyak lagi."
            ),
            Anime(
                R.drawable.film6,
                nameanime =  "Boruto The Movie",
                descanime = "Boruto Uzumaki yang bersemangat, putra Naruto Seventh Hokage, adalah seorang ninja yang terampil yang memiliki sifat kurang ajar dan gairah yang sama seperti yang pernah dimiliki ayahnya"
            ),
            Anime(
                R.drawable.film7,
                nameanime =  "Detective Conan",
                descanime = "Conan Edogawa alias Shinichi Kudo, detektif cilik yang berusaha memecahkan berbagai kasus sulit."
            ),
            Anime(
                R.drawable.film8,
                nameanime =  "One Piece",
                descanime = "Bersama dengan teman-temannya kru bajak laut Topi Jerami alias Straw Hat Pirate, Luffy bersama kawan-kawannya bertualang ke seluruh penjuru dunia untuk menemukan One Piece dan menjadi raja bajak laut."
            ),
            Anime(
                R.drawable.film9,
                nameanime =  "Doraemon",
                descanime = "Berkisah tentang kehidupan seorang anak pemalas kelas 5 sekolah dasar yang bernama Nobita Nobi (野比のび太) yang didatangi oleh sebuah robot kucing bernama Doraemon yang datang dari abad ke-22. "
            ),
            Anime(
                R.drawable.film10,
                nameanime =  "Pokemon",
                descanime = "Berkisah tentang Pokemon, makhluk unik yang masing-masing memiliki kemampuan serta penampilan unik."
            ),
            Anime(
                R.drawable.film12,
                nameanime =  "Fairy Tail",
                descanime = "Fairy Tail berkisah mengenai Lucy Heartfilia bersama dengan Natsu Dragneel yang bergabung dalam guild penyihir Fairy Tail."
            ),
            Anime(
                R.drawable.film13,
                nameanime =  "Bleach",
                descanime = "Anime ini menceritakan tentang Ichigo Kurosaki yang bertemu dengan seorang Shinigami alias dewa kematian bernama Rukia Kuchiki."
            ),
            Anime(
                R.drawable.film14,
                nameanime =  "Tokyo Revengers",
                descanime = "Tokyo Revengers berkisah tentang karakter protagonis Takemichi Hanagaki, pria berusia 26 tahun yang hidup sengsara."
            ),
            Anime(
                R.drawable.film15,
                nameanime =  "Jujutsu Kaisen",
                descanime = "Anime bergenre action dan dark fantasy ini menceritakan tentang Yuji Itadori siswa SMA berbakat, yang memutuskan untuk bergabung ke klub ilmu gaib di sekolahnya. Kemudian hidupnya mulai berubah ketika ia menemukan jimat terkutuk."
            )
        )
         val recyclerView = findViewById<RecyclerView>(R.id.rv_anime)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = AnimeAdapter(this,animeList){
            val intent = Intent (this, DetailAnimeActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }
    }
}